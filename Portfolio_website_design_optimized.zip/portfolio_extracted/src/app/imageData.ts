// Image imports - extracted from base64 for performance
import SWCNew1 from "@/assets/SWCNew1.jpg";
import MidwayImg1 from "@/assets/MidwayImg1.jpg";
import Validated1 from "@/assets/Validated1.jpg";
import Validated2 from "@/assets/Validated2.jpg";
import Validated3 from "@/assets/Validated3.jpg";
import Validated4 from "@/assets/Validated4.jpg";
import Validated5 from "@/assets/Validated5.jpg";
import Validated6 from "@/assets/Validated6.jpg";
import Validated7 from "@/assets/Validated7.jpg";
import SWC_107A6992_1 from "@/assets/SWC_107A6992_1.jpg";
import SWC_107A7023_1 from "@/assets/SWC_107A7023_1.jpg";
import SWC_107A7046 from "@/assets/SWC_107A7046.jpg";
import SWC_107A7137 from "@/assets/SWC_107A7137.jpg";
import SWC_107A6992 from "@/assets/SWC_107A6992.jpg";
import SWC_107A7023 from "@/assets/SWC_107A7023.jpg";
import SWC_107A7028 from "@/assets/SWC_107A7028.jpg";
import EditBefore from "@/assets/EditBefore.jpg";
import EditAfter from "@/assets/EditAfter.jpg";
import Taylor1c from "@/assets/Taylor1c.jpg";
import Taylor2c from "@/assets/Taylor2c.jpg";
import Aron1 from "@/assets/Aron1.jpg";
import Aron2 from "@/assets/Aron2.jpg";

export {
  SWCNew1,
  MidwayImg1,
  Validated1,
  Validated2,
  Validated3,
  Validated4,
  Validated5,
  Validated6,
  Validated7,
  SWC_107A6992_1,
  SWC_107A7023_1,
  SWC_107A7046,
  SWC_107A7137,
  SWC_107A6992,
  SWC_107A7023,
  SWC_107A7028,
  EditBefore,
  EditAfter,
  Taylor1c,
  Taylor2c,
  Aron1,
  Aron2,
};
