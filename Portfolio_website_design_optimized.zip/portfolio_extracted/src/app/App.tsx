import { useState, useEffect, useRef } from "react";
import { Menu, X, ArrowUpRight, Send, Instagram, Mail, ArrowLeft } from "lucide-react";
import { OptimizedImage } from "@/app/components/OptimizedImage";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import DriftingImg from "@/imports/Drifting.jpg";
import ArtistPortrait from "@/imports/IMG_2890-2-Edit.jpg";
import { SWCNew1, MidwayImg1, Validated1, Validated2, Validated3, Validated4, Validated5, Validated6, Validated7, SWC_107A6992, SWC_107A7023, SWC_107A7028, SWC_107A6992_1, SWC_107A7023_1, SWC_107A7046, SWC_107A7137, EditBefore, EditAfter, Taylor1c, Taylor2c, Aron1, Aron2 } from "@/app/imageData";

type Page = "landing" | "art" | "client";

// ── Photo data ───────────────────────────────────────────────────────────────

const ART_SERIES = [
  {
    name: "Flower Face",
    category: "Double Exposure · Floral Portraiture",
    photos: [
      { src: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=800&h=1100&fit=crop&auto=format", alt: "Flower Face — floral double exposure portrait" },
      { src: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=800&h=900&fit=crop&auto=format", alt: "Flower Face — soft petal overlay" },
      { src: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=540&fit=crop&auto=format", alt: "Flower Face — botanical abstraction" },
    ],
  },
  {
    name: "Nature",
    category: "Landscape · Botanical · Organic Forms",
    photos: [
      { src: "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=800&h=600&fit=crop&auto=format", alt: "Nature — open landscape study" },
      { src: "https://images.unsplash.com/photo-1504703395950-b89145a5425b?w=800&h=600&fit=crop&auto=format", alt: "Nature — abstract light and form" },
      { src: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&h=900&fit=crop&auto=format", alt: "Nature — forest and organic texture" },
      { src: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&h=880&fit=crop&auto=format", alt: "Nature — warm natural tones" },
    ],
  },
];

const CLIENTS = [
  {
    name: "Supreme Lending",
    category: "Financial Services · Brand & Team Portraits",
    photos: [
      { src: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=960&fit=crop&auto=format", alt: "Supreme Lending — professional team portrait" },
      { src: "https://images.unsplash.com/photo-1573497491765-55b3e784e2f0?w=800&h=600&fit=crop&auto=format", alt: "Supreme Lending — brand photography" },
      { src: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&h=780&fit=crop&auto=format", alt: "Supreme Lending — environment and lifestyle" },
    ],
  },
  {
    name: "Southlake Wound Care & Hyperbarics",
    category: "Medical Practice · Clinical & Team Photography",
    photos: [
      { src: SWCNew1, alt: "Southlake Wound Care — clinical photography" },
      { src: SWC_107A6992, alt: "Southlake Wound Care — clinic environment" },
      { src: SWC_107A7023, alt: "Southlake Wound Care — patient care" },
      { src: SWC_107A7028, alt: "Southlake Wound Care — treatment room" },
      { src: SWC_107A6992_1, alt: "Southlake Wound Care — clinic detail" },
      { src: SWC_107A7023_1, alt: "Southlake Wound Care — hyperbaric treatment" },
      { src: SWC_107A7046, alt: "Southlake Wound Care — patient consultation" },
      { src: SWC_107A7137, alt: "Southlake Wound Care — team photography" },
    ],
  },
  {
    name: "Validated: Add Value. Build Trust. Be Seen.",
    category: "Book & Author Brand · Editorial Photography",
    photos: [
      { src: Validated1, alt: "Validated — author brand photography" },
      { src: Validated2, alt: "Validated book — editorial photography" },
      { src: Validated3, alt: "Validated — brand content photography" },
      { src: Validated4, alt: "Validated — author portrait" },
      { src: Validated5, alt: "Validated — brand session" },
      { src: Validated6, alt: "Validated — editorial detail" },
      { src: Validated7, alt: "Validated — brand identity photography" },
    ],
  },
  {
    name: "Midway Road Animal Clinic",
    category: "Veterinary Practice · Team & Environment",
    photos: [
      { src: MidwayImg1, alt: "Midway Road Animal Clinic — clinic photography" },
      { src: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=800&h=900&fit=crop&auto=format", alt: "Midway Road Animal Clinic — pet portrait" },
      { src: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=800&h=640&fit=crop&auto=format", alt: "Midway Road Animal Clinic — clinic photography" },
    ],
  },
];

const SERVICES_ART = [
  {
    number: "01",
    title: "Fine Art Photography",
    desc: "Personal and gallery-ready work. Conceptual portrait series, fine art prints, and images made for walls — not just feeds.",
    details: ["Editorial portrait series", "Conceptual projects", "Limited print editions"],
  },
  {
    number: "02",
    title: "Documentary & Film",
    desc: "Long-form visual storytelling for personal projects and publications. Analogue and digital.",
    details: ["Personal essay projects", "Photo book editing", "Gallery exhibitions"],
  },
  {
    number: "03",
    title: "Prints & Licensing",
    desc: "Limited-edition prints available on archival media. Licensing available for editorial and publishing use.",
    details: ["Archival fine art prints", "Editorial licensing", "Commission requests"],
  },
];

const SERVICES_CLIENT = [
  {
    number: "01",
    title: "Commercial & Brand",
    desc: "Photography that makes brands look exactly how they want to feel — elevated, authentic, and impossible to scroll past.",
    details: ["Campaign photography", "Product & lifestyle", "Brand identity shoots"],
  },
  {
    number: "02",
    title: "Social Media Content",
    desc: "Batched content created for real feeds. Strategy-aware, platform-optimized, and always genuinely on-brand.",
    details: ["Monthly content packages", "Reels & story assets", "Content strategy consulting"],
  },
  {
    number: "03",
    title: "Events & Launches",
    desc: "Coverage for product launches, brand events, and activations. Fast delivery, no compromises on quality.",
    details: ["Product launches", "Brand activations", "Same-day delivery available"],
  },
];

// ── Shared components ────────────────────────────────────────────────────────

function Nav({
  onLogoClick,
  crossLabel,
  onCrossClick,
}: {
  onLogoClick: () => void;
  crossLabel: string;
  onCrossClick: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 48);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "backdrop-blur-xl bg-background/55 border-b border-white/30 shadow-lg"
          : "backdrop-blur-sm bg-white/5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        <button
          onClick={onLogoClick}
          className="font-display text-lg font-medium tracking-tight text-foreground flex items-center gap-2 hover:opacity-70 transition-opacity"
        >
          <ArrowLeft size={14} className="text-muted-foreground" />
          Sophie Knox
        </button>
        <div className="hidden md:flex items-center gap-8">
          {["Work", "About", "Services", "Contact"].map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
            >
              {link}
            </a>
          ))}
          <button
            onClick={onCrossClick}
            className="text-sm text-muted-foreground border border-border px-4 py-2 rounded-full hover:border-foreground/40 hover:text-foreground transition-colors"
          >
            {crossLabel}
          </button>
        </div>
        <button
          className="md:hidden p-1 text-foreground"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden backdrop-blur-xl bg-background/60 border-b border-white/30">
          <div className="px-6 py-8 flex flex-col gap-6">
            {["Work", "About", "Services", "Contact"].map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase()}`}
                className="font-display text-xl text-foreground"
                onClick={() => setMenuOpen(false)}
              >
                {link}
              </a>
            ))}
            <button
              onClick={() => { setMenuOpen(false); onCrossClick(); }}
              className="text-left text-sm text-muted-foreground"
            >
              {crossLabel}
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}

function ArtWork() {
  return (
    <section id="work" className="pt-32 pb-24 lg:pt-40 lg:pb-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <span className="text-sm tracking-[0.12em] uppercase text-accent">Portfolio</span>
          <h1 className="font-display text-[clamp(2.8rem,6vw,5rem)] font-medium text-foreground mt-3 leading-[1.05]">
            Fine art work
          </h1>
        </div>

        <div className="space-y-24">
          {ART_SERIES.map((series) => (
            <div key={series.name}>
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 mb-8 pb-5 border-b border-border">
                <h2 className="font-display text-2xl lg:text-3xl font-medium text-foreground">{series.name}</h2>
                <span className="text-sm tracking-[0.1em] uppercase text-muted-foreground flex-shrink-0">
                  {series.category}
                </span>
              </div>
              <ClientGallery photos={series.photos} />
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2.5 text-sm text-muted-foreground border border-border px-6 py-3 rounded-full hover:border-foreground/40 hover:text-foreground transition-colors"
          >
            <Instagram size={15} />
            More on Instagram
            <ArrowUpRight size={13} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-secondary/40">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="grid grid-cols-5 grid-rows-3 gap-3 h-[480px] lg:h-[560px]">
          <div className="col-span-3 row-span-3 rounded-2xl overflow-hidden bg-muted">
            <OptimizedImage
              src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&h=840&fit=crop&auto=format"
              alt="Portrait series"
              className="w-full h-full"
              sizes="(max-width: 1024px) 60vw, 30vw"
            />
          </div>
          <div className="col-span-2 row-span-2 rounded-2xl overflow-hidden bg-muted">
            <OptimizedImage
              src="https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=400&h=500&fit=crop&auto=format"
              alt="Natural light portrait"
              className="w-full h-full"
              sizes="(max-width: 1024px) 40vw, 20vw"
            />
          </div>
          <div className="col-span-2 row-span-1 rounded-2xl bg-accent/15 flex items-center justify-center">
            <div className="text-center px-4">
              <div className="font-display text-3xl text-accent leading-none">8+</div>
              <div className="text-[11px] text-muted-foreground mt-1.5 leading-snug tracking-wide">years<br />of light</div>
            </div>
          </div>
        </div>
        <div>
          <span className="text-sm tracking-[0.12em] uppercase text-accent">About me</span>
          <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium text-foreground mt-4 mb-6 leading-[1.1]">
            Light chaser.<br />Story finder.<br />Visual obsessive.
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-5 text-[16px]">
            {"Hi, I'm Sophie. I've spent over eight years turning quiet moments into lasting images — for myself, for galleries, and for brands that care about how they're seen in the world."}
          </p>
          <p className="text-muted-foreground leading-relaxed mb-8 text-[16px]">
            My work lives at the edge of fine art and commercial photography. Whether shooting a portrait series for a gallery show or creating social content for a beauty brand, I bring the same eye: deliberate, warm, and a little unexpected.
          </p>
          <blockquote className="border-l-2 border-accent pl-5 mb-10">
            <p className="font-display text-[1.2rem] italic text-foreground/75 leading-relaxed">
              "The best photographs are the ones that make you stop scrolling."
            </p>
          </blockquote>
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 text-sm text-foreground border border-foreground/20 px-5 py-2.5 rounded-full hover:border-foreground/60 transition-colors"
          >
            Work with me
            <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
}

function ArtAbout() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-secondary/40">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">

        {/* Single portrait image — full uncropped, natural aspect ratio */}
        <div className="rounded-2xl overflow-hidden bg-black w-full">
          <img
            src={ArtistPortrait}
            alt="Knox — double exposure portrait with hydrangea petals"
            className="w-full h-auto block"
            loading="lazy"
            decoding="async"
          />
        </div>

        {/* Artist statement */}
        <div className="lg:pt-8">
          <span className="text-sm tracking-[0.12em] uppercase text-accent">Artist Statement</span>
          <h2 className="font-display text-[clamp(2.5rem,5vw,4rem)] font-medium text-foreground mt-4 mb-10 leading-none">
            Knox
          </h2>
          <div className="space-y-6 text-foreground/75 text-[17px] leading-[1.75]">
            <p>
              Knox is a mixed media artist exploring the layers between what is seen and what is hidden through experimental processes in photography and sculpture.
            </p>
            <p>
              She investigates how natural structures can be deconstructed and reassembled to create something simultaneously familiar and otherworldly.
            </p>
            <p>
              Blending lumen prints, digital layering, assemblage, and carving, Knox works across mediums to examine transformation and transparency.
            </p>
            <p>
              Her practice reveals the boundaries between the organic and the imagined—uncovering what lies beneath the surface.
            </p>
          </div>

          {/* Subtle divider + contact CTA */}
          <div className="mt-12 pt-10 border-t border-border">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 text-sm text-foreground border border-foreground/20 px-5 py-2.5 rounded-full hover:border-foreground/60 transition-colors"
            >
              Work with me
              <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Services({ items }: { items: typeof SERVICES_ART }) {
  return (
    <section id="services" className="py-24 lg:py-32 bg-foreground relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.025]"
        style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "28px 28px" }}
      />
      <div
        className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full opacity-10 pointer-events-none"
        style={{ background: "radial-gradient(circle, #d4785f 0%, transparent 70%)", transform: "translate(30%, -30%)" }}
      />
      <div className="relative max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <span className="text-sm tracking-[0.12em] uppercase text-accent">What I offer</span>
          <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium text-primary-foreground mt-4">
            How I can help
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {items.map((service) => (
            <div
              key={service.number}
              className="backdrop-blur-xl bg-white/[0.08] border border-white/15 rounded-3xl p-8 hover:bg-white/[0.15] hover:border-white/25 transition-all duration-300 shadow-lg shadow-black/20"
            >
              <div className="text-[10px] font-mono-label text-accent mb-8">{service.number}</div>
              <h3 className="font-display text-[1.4rem] font-medium text-primary-foreground mb-4 leading-snug">
                {service.title}
              </h3>
              <p className="text-primary-foreground/45 text-[14px] leading-relaxed mb-8">{service.desc}</p>
              <ul className="space-y-2.5">
                {service.details.map((d) => (
                  <li key={d} className="flex items-center gap-2.5 text-[13px] text-primary-foreground/55">
                    <span className="w-1 h-1 rounded-full bg-accent flex-shrink-0" />
                    {d}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-xl mx-auto px-6">
        <div className="text-center mb-12">
          <span className="text-sm tracking-[0.12em] uppercase text-accent">Get in touch</span>
          <h2 className="font-display text-[clamp(2rem,4vw,3rem)] font-medium text-foreground mt-4 mb-4">
            {"Let's make something"}
          </h2>
          <p className="text-muted-foreground text-[16px] leading-relaxed">
            Whether you have a project in mind or just want to say hello — my inbox is always open.
          </p>
        </div>
        <div className="backdrop-blur-2xl bg-white/50 border border-white/50 rounded-3xl p-8 lg:p-10 shadow-2xl ring-1 ring-white/20">
          {sent ? (
            <div className="text-center py-8">
              <div className="font-display text-5xl text-accent mb-4">✓</div>
              <h3 className="font-display text-2xl font-medium text-foreground mb-2">Message sent!</h3>
              <p className="text-muted-foreground text-sm">{"I'll be in touch within 1–2 business days."}</p>
              <button
                onClick={() => setSent(false)}
                className="mt-6 text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground transition-colors"
              >
                Send another
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="text-[10px] text-muted-foreground font-mono-label uppercase block mb-2">Name</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Your name"
                    required
                    className="w-full bg-white/80 border border-border/60 rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-foreground/30 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-muted-foreground font-mono-label uppercase block mb-2">Email</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="your@email.com"
                    required
                    className="w-full bg-white/80 border border-border/60 rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-foreground/30 transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground font-mono-label uppercase block mb-2">Message</label>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Tell me about your project..."
                  rows={5}
                  required
                  className="w-full bg-white/80 border border-border/60 rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-foreground/30 transition-colors resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-foreground text-primary-foreground py-3.5 rounded-xl text-sm font-medium hover:opacity-75 transition-opacity flex items-center justify-center gap-2"
              >
                Send message <Send size={14} />
              </button>
            </form>
          )}
        </div>
        <div className="flex flex-wrap items-center justify-center gap-6 mt-10 text-sm text-muted-foreground">
          <a href="mailto:hello@sophieknox.com" className="flex items-center gap-1.5 hover:text-foreground transition-colors">
            <Mail size={14} /> hello@sophieknox.com
          </a>
          <span className="text-border select-none">·</span>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-foreground transition-colors">
            <Instagram size={14} /> @sophieknox
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer({ onLogoClick }: { onLogoClick: () => void }) {
  return (
    <footer className="border-t border-border py-8 px-6">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
        <button onClick={onLogoClick} className="font-display text-foreground font-medium hover:opacity-70 transition-opacity">
          Sophie Knox
        </button>
        <span className="text-center sm:text-right text-xs">
          © 2024 · All images are the property of Sophie Knox Photography
        </span>
      </div>
    </footer>
  );
}

// ── Landing Screen ───────────────────────────────────────────────────────────

function LandingScreen({ onChoose }: { onChoose: (page: "art" | "client") => void }) {
  const [hovered, setHovered] = useState<"art" | "client" | null>(null);
  const [leaving, setLeaving] = useState(false);

  const choose = (page: "art" | "client") => {
    setLeaving(true);
    setTimeout(() => onChoose(page), 550);
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex flex-col lg:flex-row"
      style={{ opacity: leaving ? 0 : 1, transition: "opacity 0.55s ease", pointerEvents: leaving ? "none" : "auto" }}
    >
      {/* Name badge */}
      <div className="absolute top-8 left-0 right-0 flex justify-center z-10 pointer-events-none">
        <span className="font-display text-sm font-medium text-white/90 tracking-wide drop-shadow-md">
          Sophie Knox
        </span>
      </div>

      {/* Art side */}
      <button
        className="relative flex-1 flex items-end justify-start p-10 lg:p-14 overflow-hidden cursor-pointer border-0 text-left"
        style={{ minHeight: "50vh" }}
        onMouseEnter={() => setHovered("art")}
        onMouseLeave={() => setHovered(null)}
        onClick={() => choose("art")}
        aria-label="Enter Art Photography"
      >
        {/* Drifting.jpg as the art landing image */}
        <ImageWithFallback
          src={DriftingImg}
          alt="Fine art photography — Drifting"
          className="absolute inset-0 w-full h-full object-contain"
          style={{
            transform: hovered === "art" ? "scale(1.05)" : "scale(1)",
            transition: "transform 0.7s ease",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/40" />
        <div
          className="absolute inset-0 bg-accent/15 pointer-events-none"
          style={{ opacity: hovered === "art" ? 1 : 0, transition: "opacity 0.4s ease" }}
        />
        <div className="relative z-10">
          <span className="text-sm tracking-[0.12em] uppercase text-white/50 block mb-3">Fine Art</span>
          <h2 className="font-display text-4xl lg:text-6xl font-medium text-white leading-[1.05] mb-5">
            Art<br />Photography
          </h2>
          <div
            className="flex items-center gap-2 text-sm text-white/70"
            style={{ transition: "gap 0.3s, color 0.3s", gap: hovered === "art" ? "0.75rem" : "0.5rem", color: hovered === "art" ? "white" : undefined }}
          >
            Enter <ArrowUpRight size={15} />
          </div>
        </div>
        <div className="hidden lg:block absolute right-0 top-0 bottom-0 w-px bg-white/15" />
      </button>

      {/* Client side */}
      <button
        className="relative flex-1 flex items-end justify-start p-10 lg:p-14 overflow-hidden cursor-pointer border-0 text-left"
        style={{ minHeight: "50vh" }}
        onMouseEnter={() => setHovered("client")}
        onMouseLeave={() => setHovered(null)}
        onClick={() => choose("client")}
        aria-label="Enter Commercial Photography"
      >
        <OptimizedImage
          src="https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1200&h=1600&fit=crop&auto=format"
          alt="Commercial photography"
          className="absolute inset-0 w-full h-full"
          priority
          sizes="50vw"
          style={{
            transform: hovered === "client" ? "scale(1.05)" : "scale(1)",
            transition: "transform 0.7s ease",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/40" />
        <div
          className="absolute inset-0 bg-accent/15 pointer-events-none"
          style={{ opacity: hovered === "client" ? 1 : 0, transition: "opacity 0.4s ease" }}
        />
        <div className="relative z-10">
          <span className="text-sm tracking-[0.12em] uppercase text-white/50 block mb-3">Commercial</span>
          <h2 className="font-display text-4xl lg:text-6xl font-medium text-white leading-[1.05] mb-5">
            Client<br />Photography
          </h2>
          <div
            className="flex items-center gap-2 text-sm text-white/70"
            style={{ transition: "gap 0.3s, color 0.3s", gap: hovered === "client" ? "0.75rem" : "0.5rem", color: hovered === "client" ? "white" : undefined }}
          >
            Enter <ArrowUpRight size={15} />
          </div>
        </div>
      </button>
    </div>
  );
}

// ── Art Photography Page ─────────────────────────────────────────────────────

function ArtPage({ onBack, onSwitch }: { onBack: () => void; onSwitch: () => void }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav onLogoClick={onBack} crossLabel="View Client Work →" onCrossClick={onSwitch} />

      {/* Hero — full-viewport, Drifting.jpg */}
      <section className="relative h-screen w-full overflow-hidden bg-black">
        <ImageWithFallback
          src={DriftingImg}
          alt="Drifting — hydrangeas floating in dark water"
          className="absolute inset-0 w-full h-full object-contain object-center"
          style={{ opacity: 0.9 }}
        />
        {/* Gradient for text legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/20 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

        {/* Text — anchored to bottom-left in the dark area */}
        <div className="absolute bottom-0 left-0 p-10 lg:p-16 max-w-xl">
          <span className="text-sm tracking-[0.12em] uppercase text-white/40 block mb-6">
            Fine Art Photography
          </span>
          <h1 className="font-display text-[clamp(3rem,6vw,5.5rem)] font-medium leading-[1.05] text-white mb-6">
            Images that<br />
            <em className="not-italic italic text-accent">live</em> beyond<br />
            the moment
          </h1>
          <p className="text-white/55 text-[16px] leading-relaxed mb-8 max-w-sm">
            Fine art and editorial photography. From intimate portrait series to gallery-ready prints — always deliberate, always felt.
          </p>
          <a
            href="#work"
            className="group inline-flex items-center gap-2 bg-white/15 backdrop-blur-md border border-white/25 text-white px-6 py-3 rounded-full text-sm hover:bg-white/25 transition-colors"
          >
            See the work
            <ArrowUpRight size={15} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </div>

        {/* Glass tag */}
        <div className="absolute bottom-10 right-10 hidden lg:block backdrop-blur-xl bg-white/15 border border-white/20 rounded-2xl px-4 py-3.5 shadow-xl ring-1 ring-white/10">
          <div className="text-[10px] text-white/40 mb-0.5 tracking-wider uppercase">Featured work</div>
          <div className="text-sm font-medium text-white">Drifting, 2024</div>
        </div>
      </section>

      <ArtWork />
      <ArtAbout />
      <Services items={SERVICES_ART} />
      <Contact />
      <Footer onLogoClick={onBack} />
    </div>
  );
}

// ── Client Photography Page ──────────────────────────────────────────────────

function ClientGallery({ photos }: { photos: { src: string; alt: string }[] }) {
  const [lightbox, setLightbox] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: -1 | 1) => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.7, behavior: "smooth" });
  };

  useEffect(() => {
    if (lightbox === null) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(null);
      if (e.key === "ArrowRight") setLightbox((l) => l !== null ? (l + 1) % photos.length : null);
      if (e.key === "ArrowLeft") setLightbox((l) => l !== null ? (l - 1 + photos.length) % photos.length : null);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [lightbox, photos.length]);

  return (
    <>
      <div className="relative group/strip">
        {/* Scroll strip */}
        <div
          ref={scrollRef}
          className="flex flex-row gap-2 overflow-x-auto scrollbar-none scroll-smooth"
          style={{ scrollbarWidth: "none" }}
        >
          {photos.map((photo, i) => (
            <img
              key={i}
              src={photo.src}
              alt={photo.alt}
              className="h-72 w-auto flex-shrink-0 cursor-zoom-in block"
              loading="lazy"
              decoding="async"
              onClick={() => setLightbox(i)}
            />
          ))}
        </div>

        {/* Arrows */}
        <button
          onClick={() => scroll(-1)}
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-foreground text-primary-foreground flex items-center justify-center shadow-lg hover:opacity-75 transition-opacity opacity-0 group-hover/strip:opacity-100"
          aria-label="Scroll left"
        >
          <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
            <path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <button
          onClick={() => scroll(1)}
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-10 h-10 rounded-full bg-foreground text-primary-foreground flex items-center justify-center shadow-lg hover:opacity-75 transition-opacity opacity-0 group-hover/strip:opacity-100"
          aria-label="Scroll right"
        >
          <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
            <path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/92 backdrop-blur-sm"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-5 right-5 w-10 h-10 rounded-full bg-white/15 border border-white/25 flex items-center justify-center text-white hover:bg-white/25 transition-colors"
            onClick={() => setLightbox(null)}
            aria-label="Close"
          >
            <X size={18} />
          </button>

          {photos.length > 1 && (
            <>
              <button
                className="absolute left-5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white text-foreground flex items-center justify-center shadow-xl hover:opacity-80 transition-opacity"
                onClick={(e) => { e.stopPropagation(); setLightbox((l) => l !== null ? (l - 1 + photos.length) % photos.length : null); }}
                aria-label="Previous"
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              <button
                className="absolute right-5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white text-foreground flex items-center justify-center shadow-xl hover:opacity-80 transition-opacity"
                onClick={(e) => { e.stopPropagation(); setLightbox((l) => l !== null ? (l + 1) % photos.length : null); }}
                aria-label="Next"
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </>
          )}

          <img
            src={photos[lightbox].src}
            alt={photos[lightbox].alt}
            className="max-w-[88vw] max-h-[88vh] object-contain rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </>
  );
}

function ClientWork() {
  return (
    <section id="work" className="pt-32 pb-24 lg:pt-40 lg:pb-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <span className="text-sm tracking-[0.12em] uppercase text-accent">Portfolio</span>
          <h1 className="font-display text-[clamp(2.8rem,6vw,5rem)] font-medium text-foreground mt-3 leading-[1.05]">
            Client work
          </h1>
        </div>

        <div className="space-y-24">
          {/* Supreme Lending — Video */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 mb-8 pb-5 border-b border-border">
              <h2 className="font-display text-2xl lg:text-3xl font-medium text-foreground">Supreme Lending</h2>
              <span className="text-sm tracking-[0.1em] uppercase text-muted-foreground flex-shrink-0">
                Financial Services · Brand Video
              </span>
            </div>
            {/* Replace href with the actual video URL */}
            <a
              href="https://www.youtube.com/watch?v=REPLACE_WITH_VIDEO_ID"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative inline-flex items-center gap-5 h-72 pl-6 pr-10 rounded-2xl bg-foreground overflow-hidden transition-colors duration-200 hover:bg-accent"
            >
              <div className="flex-shrink-0 w-14 h-14 rounded-full bg-white/15 border border-white/25 flex items-center justify-center transition-colors duration-200 group-hover:bg-white/30">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </div>
              <div>
                <p className="text-white font-display text-xl font-medium leading-snug">Supreme Lending Brand Video</p>
                <p className="text-white/50 text-sm mt-1 transition-colors duration-200 group-hover:text-white/70">Click to watch ↗</p>
              </div>
            </a>
          </div>

          {CLIENTS.map((client) => (
            <div key={client.name}>
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 mb-8 pb-5 border-b border-border">
                <h2 className="font-display text-2xl lg:text-3xl font-medium text-foreground">{client.name}</h2>
                <span className="text-sm tracking-[0.1em] uppercase text-muted-foreground flex-shrink-0">
                  {client.category}
                </span>
              </div>
              <ClientGallery photos={client.photos} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BeforeAfter({ before, after, edits }: { before: string; after: string; edits: string[] }) {
  const [position, setPosition] = useState(50);
  const [dragging, setDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const updatePosition = (clientX: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const pct = Math.min(Math.max(((clientX - rect.left) / rect.width) * 100, 0), 100);
    setPosition(pct);
  };

  return (
    <div className="mt-16 max-w-xl">
      {/* Slider */}
      <div
        ref={containerRef}
        className="relative overflow-hidden rounded-2xl cursor-col-resize select-none"
        onMouseMove={(e) => updatePosition(e.clientX)}
        onMouseDown={() => setDragging(true)}
        onMouseUp={() => setDragging(false)}
        onMouseLeave={() => setDragging(false)}
        onTouchMove={(e) => updatePosition(e.touches[0].clientX)}
      >
        {/* Before (base layer) */}
        <img src={before} alt="Before editing" className="w-full h-64 object-contain block" draggable={false} />

        {/* After (clipped overlay) */}
        <div
          className="absolute inset-0"
          style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}
        >
          <img src={after} alt="After editing" className="w-full h-64 object-contain block" draggable={false} />
        </div>

        {/* Divider */}
        <div
          className="absolute top-0 bottom-0 w-[2px] bg-white shadow-[0_0_8px_rgba(0,0,0,0.4)]"
          style={{ left: `${position}%` }}
        >
          {/* Handle */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white shadow-xl flex items-center justify-center gap-0.5">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M4 7H1m0 0 2-2M1 7l2 2M10 7h3m0 0-2-2m2 2-2 2" stroke="#1c1917" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>

        {/* Labels */}
        <div className="absolute top-3 left-3 text-xs font-medium text-white bg-black/50 backdrop-blur-sm px-2.5 py-1 rounded-full tracking-wide">Before</div>
        <div className="absolute top-3 right-3 text-xs font-medium text-white bg-black/50 backdrop-blur-sm px-2.5 py-1 rounded-full tracking-wide">After</div>
      </div>

      {/* Edit notes */}
      <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-x-8 gap-y-2">
        {edits.map((edit) => (
          <div key={edit} className="flex items-start gap-2 text-[14px] text-foreground/70">
            <span className="mt-[5px] w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
            {edit}
          </div>
        ))}
      </div>
    </div>
  );
}

function PhotoEditing() {
  const services = [
    {
      title: "Retouching & Skin Work",
      desc: "Natural, intentional retouching — removing distractions while keeping the subject real. No over-smoothed, plasticky results.",
    },
    {
      title: "Color Grading",
      desc: "Cohesive tonal treatment across a full shoot. Whether you need a warm editorial feel or a clean clinical look, color is matched to brand.",
    },
    {
      title: "Composite & Layering",
      desc: "Combining exposures, swapping backgrounds, and blending elements to build an image that couldn't exist in a single frame.",
    },
    {
      title: "Batch Editing",
      desc: "Consistent, fast edits across large sets — ideal for events, e-commerce, and social media content drops.",
    },
    {
      title: "Lumen Print Processing",
      desc: "Digital post-processing of lumen and alternative-process prints, enhancing the organic chemistry while preserving its unpredictability.",
    },
    {
      title: "File Prep & Delivery",
      desc: "Export optimized for web, print, or social. Includes ICC profile matching, resolution checks, and organized delivery folders.",
    },
  ];

  return (
    <section id="editing" className="py-24 lg:py-32 bg-secondary/40">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <span className="text-sm tracking-[0.12em] uppercase text-accent">Editing services</span>
          <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium text-foreground mt-3">
            Photo editing
          </h2>
          <p className="text-muted-foreground text-[16px] leading-relaxed mt-4 max-w-xl">
            Editing is offered as a standalone service. Send your raws, get back files that are finished, consistent, and ready to use.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border rounded-2xl overflow-hidden">
          {services.map((s) => (
            <div key={s.title} className="bg-background p-8 hover:bg-muted/50 transition-colors duration-200">
              <h3 className="font-display text-lg font-medium text-foreground mb-3">{s.title}</h3>
              <p className="text-muted-foreground text-[14px] leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-16">
          <BeforeAfter
            before={EditAfter}
            after={EditBefore}
            edits={[
              "Skin color matching",
              "Frizzy hair removal",
              "Skin retouching",
              "Background cleanup",
              "Exposure & contrast balance",
              "Facial shadow removal",
            ]}
          />
          <BeforeAfter
            before={Taylor1c}
            after={Taylor2c}
            edits={[
              "Skin color matching",
              "Frizzy hair removal",
              "Skin retouching",
              "Background cleanup",
              "Exposure & contrast balance",
              "Facial shadow removal",
            ]}
          />
          <BeforeAfter
            before={Aron1}
            after={Aron2}
            edits={[
              "Skin color matching",
              "Frizzy hair removal",
              "Skin retouching",
              "Background cleanup",
              "Exposure & contrast balance",
              "Facial shadow removal",
            ]}
          />
        </div>

        <div className="mt-12 flex flex-wrap gap-4 items-center">
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 bg-foreground text-primary-foreground px-6 py-3 rounded-full text-sm hover:opacity-75 transition-opacity"
          >
            Inquire about editing
            <ArrowUpRight size={15} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
          <span className="text-sm text-muted-foreground">Turnaround: 3–5 business days for most sets</span>
        </div>
      </div>
    </section>
  );
}

function ClientPage({ onBack, onSwitch }: { onBack: () => void; onSwitch: () => void }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav onLogoClick={onBack} crossLabel="View Art Work →" onCrossClick={onSwitch} />
      <ClientWork />
      <PhotoEditing />
      <About />
      <Services items={SERVICES_CLIENT} />
      <Contact />
      <Footer onLogoClick={onBack} />
    </div>
  );
}

// ── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState<Page>("landing");

  useEffect(() => {
    if (page !== "landing") {
      window.scrollTo({ top: 0, behavior: "instant" });
    }
  }, [page]);

  if (page === "art") {
    return (
      <ArtPage
        onBack={() => setPage("landing")}
        onSwitch={() => setPage("client")}
      />
    );
  }

  if (page === "client") {
    return (
      <ClientPage
        onBack={() => setPage("landing")}
        onSwitch={() => setPage("art")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <LandingScreen onChoose={(p) => setPage(p)} />
    </div>
  );
}
